# === External libraries ===
import os, threading, time

from src.ta.utils.helper import setup_env, kill_uvicorn_on_port, open_swagger, start_cloudflared
setup_env() # 🛠 Ensure environment + dependencies before importing anything else
# --- Imports  AFTER setup_env ---
import uvicorn,json
from src.ta.functions import *
from src.ta.tests.general import *
#########
from src.ta.functions.indicators.universal_threshold_dispatcher  import *
from src.ta.functions.indicators.universal_indicator_dispatcher import *
from src.ta.functions.indicators.threshold_functions import *
from src.ta.functions.plots import *
from src.ta.ml.optimizers.search import *

from src.ta.data.fetch_yfinance import download_underlying_stock
from src.ta.ml.optimizers.search import *
import matplotlib.pyplot as plt
from src.ta.ml.optimizers.searchSpaces import *
from pprint import pprint



#DB specific
from src.ta.db.market_db import *
import src.ta.db.market_db as taDB





underlying_stock = "BTC-USD"
start="2022-02-06"
end="2025-11-27"
tmfrm='1d' #1d 1wk

#Download Set
df = download_underlying_stock(title=underlying_stock,start=start,end=end,tmfrm="1d",plot=False)
#print(df)












def main():
    print("✅ All dependencies ready. Program running...")
    

    

    '''
    # Convert list-of-dicts → JSON string
    df = pd.DataFrame([{
        "name": "cutBUY",
        "config_json": json.dumps(cutBUY)
    }])

    # Save it
    taDB.save_table("search_spaces", df)
    


    df = taDB.load_table("search_spaces")
    row = df[df["name"] == "cutBUY"].iloc[0]
    cutBUY_loaded = json.loads(row["config_json"])
    pprint(cutBUY_loaded)
    '''
    
    #taDB.save_table("eth", df)
    #taDB.list_tables()
    #table = taDB.load_table("search_spaces")
    #print(table)

    '''
    signals = mixThresholds(df, [ssBUY[0]], mode="and")
    taDB.save_table("sigs", signals)

    table = taDB.load_table("sigs")
    print(table)
    '''


    buy_cfgs = [irtBUY[5],irtBUY[7]]

    signals_buy = mixThresholds(
        df,
        buy_cfgs,
        mode="and",         # AND = both conditions must overlap
        search="grid"       # gridSearch used for multi-dimensional configs
    )

    print("BUY signals:")
    print(signals_buy)



    # Skip gridSearch entirely - just combine the original configs
    #combined_cfg = mixThresholds(df, [srsi, williams], mode="and")
    #print("Combined CFG =", combined_cfg)



   


    # Plot the results into a PDF
    plot_results_pdf(df, signals_buy["blocks"][0], pdf_name="Block0.pdf")
    plot_results_pdf(df, signals_buy["blocks"][1], pdf_name="Block1.pdf")
    plot_results_pdf(df, signals_buy["final"], pdf_name="final.pdf")
    '''
    pd.set_option("display.max_rows", None)
    pd.set_option("display.max_columns", None)
    pd.set_option("display.width", None)
    pd.set_option("display.max_colwidth", None)
    


    
    signals0 = mixThresholds(df, [ssBUY[0]], mode="and")
    print("\n Config 0  :\n",signals0)
    
    signals1 = mixThresholds(df, [ssBUY[1]], mode="and")
    print("\n Config 1  :\n",signals1)

    signals2 = mixThresholds(df, [ssBUY[2]], mode="and")
    print("\n Config 2  :\n",signals2)

    signals = mixThresholds(df, [ssBUY[0],ssBUY[1],ssBUY[2]], mode="and")
    print("\nAll Configs (MixThresholds) :\n",signals)

    sig1 = mixThresholds(df, [cultBUY[0]], mode="and")
    print("\nAll Configs (MixThresholds) :\n",sig1)

    # Plot the results into a PDF
    plot_results_pdf(df, sig1, pdf_name="cutBuy.pdf",top_n=200)

    
  
    
    -----------------------------------------------------
    



    # Show links
    print("\n🚀 FastAPI server starting...")
    print("📑 Swagger docs:   http://127.0.0.1:8000/docs")

    
    # Kill any leftover uvicorn
    kill_uvicorn_on_port(8000)

    # ✅ Launch Swagger in browser BEFORE  uvicorn
    open_swagger("http://127.0.0.1:8000/docs")

    # Start cloudflared in background with delay
    #threading.Thread(target=start_cloudflared, daemon=True).start()

    # Run the GLOBAL app
    uvicorn.run("app:app", host="127.0.0.1", port=8000)
    '''
    
    

if __name__ == "__main__":
    main()
