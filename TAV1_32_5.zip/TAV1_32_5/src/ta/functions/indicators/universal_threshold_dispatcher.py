# === External libraries ===
import pandas as pd
import numpy as np
import time

# === Indicator functions ===
from src.ta.functions.indicators.trend_indicators import *
from src.ta.functions.indicators.momentum_indicators import *
from src.ta.functions.indicators.volatility_indicators import *
from src.ta.functions.indicators.universal_indicator_dispatcher import *

# === Threshold functions ===
from src.ta.functions.indicators.threshold_functions import *


#? ======================================================
#? UNIVERSAL DISPATCH FOR ONE CONFIG
#? ======================================================
def run_threshold_config(df, cfg):
    """
    Dynamically call the correct threshold function based on config["type"].
    Each config in apiBUY/apiSELL must follow the expected dictionary structure.

    Expected universal config format (lists, even if scalar):
        {
            "type": "crossUpThreshold",
            "indicator": "rsi",
            "period": [14],
            "threshold": [30],
            "wd": 0,
            "indicator_params": {...}
        }
    """

    t = cfg["type"]

    # --------------------------------------------------
    # crossUpThreshold  (one indicator, one threshold)
    # --------------------------------------------------
    if t == "crossUpThreshold":
        return crossUpThreshold(
            df,
            type=cfg["indicator"],
            thr=cfg["threshold"][0],        # list → scalar
            period=cfg["period"][0],        # list → scalar
            wd=cfg.get("wd", 0),
            **cfg.get("indicator_params", {})
        )

    # --------------------------------------------------
    # crossUpLineThreshold (indicator vs indicator)
    # --------------------------------------------------
    elif t == "crossUpLineThreshold":
        return crossUpLineThreshold(
            df,
            type1=cfg["indicators"][0],
            period1=cfg["periods"][0][0],
            type2=cfg["indicators"][1],
            period2=cfg["periods"][1][0],
            wd=cfg.get("wd", 0),
        )

    # --------------------------------------------------
    # inRangeThreshold
    # --------------------------------------------------
    elif t == "inRangeThreshold":
        return inRangeThreshold(
            df,
            type=cfg["indicator"],
            period=cfg["period"][0],
            lower=cfg["lower"][0],
            upper=cfg["upper"][0],
            **cfg.get("indicator_params", {})
        )

    # --------------------------------------------------
    # timeThreshold
    # --------------------------------------------------
    elif t == "timeThreshold":
        return timeThreshold(
            df,
            type=cfg["indicator"],
            period=cfg["period"][0],
            level=cfg["threshold"][0],
            direction=cfg["direction"][0],
            min_candles=cfg["min_candles"][0],
            wd=cfg.get("wd", 0),
            **cfg.get("indicator_params", {})
        )

    else:
        raise ValueError(f"Unknown threshold type: {t}")


#? ======================================================
#? SIGNAL MIXING (AND / OR)
#? ======================================================
def intersect_signals(results):
    """AND logic — only dates appearing in ALL signal sets."""
    if not results:
        return pd.DataFrame()

    merged = results[0][["Date"]].copy()
    for r in results[1:]:
        merged = merged.merge(r[["Date"]], on="Date", how="inner")

    return merged


def union_signals(results):
    """OR logic — unique union of all dates."""
    if not results:
        return pd.DataFrame()

    merged = pd.concat([r[["Date"]] for r in results]).drop_duplicates()
    return merged.sort_values("Date")


#? ======================================================
#? Helper: detect multidimensional (search-space) configs
#? ======================================================
def is_multidimensional_config(cfg):
    """
    Returns True if the config contains list-ranges (search space), i.e.
    any top-level field or indicator_params field has a list with len > 1.
    Length-1 lists are treated as scalars.
    """
    for k, v in cfg.items():
        if k == "indicator_params":
            if isinstance(v, dict):
                for vv in v.values():
                    if isinstance(vv, list) and len(vv) > 1:
                        return True
        else:
            if isinstance(v, list) and len(v) > 1:
                return True
    return False


#? ======================================================
#? mixThresholds — NEW VERSION (config + search-based)
#? Option B: union ALL configs inside each block
#? ======================================================
def mixThresholds(df, configs, mode="and", search="grid"):
    """
    CLEAN VERSION (Option B):
        - scalar config → runs once
        - search-space config → uses grid/random/bayesian search
        - collects ALL sub-config results per block
        - unions signals inside each block
        - AND/OR mixes all blocks into final result
        - returns FLAT, plot_results_pdf-ready structure:

            {
                "final":  {config, signals, signals_df},
                "blocks": [
                    [ {config, signals, signals_df}, ... ],   # block 0
                    [ {config, signals, signals_df}, ... ],   # block 1
                    ...
                ]
            }
    """

    # Import here to avoid circular import
    from src.ta.ml.optimizers.search import (
        gridSearch,
        run_threshold
    )

    # randomly/bayesian imported only when used
    all_blocks_results = []     # list of blocks; each block = list of dicts
    block_union_dfs = []        # list of DFS containing only ["Date"]

    for cfg in configs:

        # =====================================================
        # CASE 1: scalar config (no multi-dimensional lists)
        # =====================================================
        if not is_multidimensional_config(cfg):
            df_sig = run_threshold_config(df, cfg)

            if df_sig is None or df_sig.empty:
                # no signals; block empty
                all_blocks_results.append([])
                block_union_dfs.append(pd.DataFrame(columns=["Date"]))
            else:
                # single config result formatted for plot_results_pdf
                item = {
                    "config": cfg,
                    "signals": len(df_sig),
                    "signals_df": df_sig
                }
                all_blocks_results.append([item])        # FLAT list
                block_union_dfs.append(df_sig[["Date"]])
            continue

        # =====================================================
        # CASE 2: multidimensional config → apply SEARCH
        # =====================================================
        if search == "grid":
            search_results = gridSearch(df, [cfg])

        #elif search == "random":
        #    from src.ta.functions.indicators.search import randomSearch
        #    search_results = randomSearch(df, [cfg])

        #elif search == "bayesian":
        #    from src.ta.functions.indicators.search import bayesianSearch
        #    search_results = bayesianSearch(df, [cfg])

        else:
            raise ValueError("search must be 'grid', 'random', or 'bayesian'")

        block_items = []       # configs in this block
        block_date_dfs = []    # raw list of ["Date"] dfs

        # search_results: list of {"config": low_cfg, "signals": n}
        for sr in search_results:
            low_cfg = sr["config"]

            # run using universal threshold executor
            df_sig = run_threshold(df, low_cfg)

            if df_sig is None or df_sig.empty:
                continue

            block_items.append({
                "config": low_cfg,
                "signals": len(df_sig),
                "signals_df": df_sig
            })

            block_date_dfs.append(df_sig[["Date"]])

        # append FLAT list of block configs
        all_blocks_results.append(block_items)

        # now union dates inside block (Option B)
        if not block_date_dfs:
            block_union_dfs.append(pd.DataFrame(columns=["Date"]))
        else:
            union_df = (
                pd.concat(block_date_dfs)
                .drop_duplicates()
                .sort_values("Date")
            )
            block_union_dfs.append(union_df)

    # =====================================================
    # MIX ACROSS BLOCKS via AND / OR
    # =====================================================
    if mode == "and":
        final_dates = intersect_signals(block_union_dfs)
    else:
        final_dates = union_signals(block_union_dfs)

    # attach close price
    if final_dates.empty:
        final_df = pd.DataFrame(columns=["Date", "signal"])
    else:
        final_df = final_dates.merge(df[["Date", "close"]], on="Date", how="left")
        final_df = final_df.rename(columns={"close": "signal"})

    # format final for plot_results_pdf
    final_item = {
        "config": {"type": "mixThreshold"},
        "signals": len(final_df),
        "signals_df": final_df
    }

    return {
        "final": final_item,        # dict
        "blocks": all_blocks_results  # list of flat lists
    }








#? ======================================================
#? Distance between threshold triggering
#? ======================================================
def threshold_distance(df, cfg):
    """Returns % distance of CURRENT candle from triggering the threshold."""
    latest = df.iloc[-1]
    t = cfg["type"]

    indicator = cfg.get("indicator")
    ind_params = cfg.get("indicator_params", {})

    # get correct period
    if "period" in cfg:
        period = cfg["period"][0] if isinstance(cfg["period"], list) else cfg["period"]
    else:
        period = None

    # compute indicator value if not lineThreshold
    if indicator:
        ind_df = calculate_indicator(df.copy(), type=indicator, period=period, plot=False, **ind_params)
        col = [c for c in ind_df.columns if c != "Date"][0]
        value = ind_df[col].iloc[-1]

    # -------- CROSS UP THRESHOLD --------
    if t == "crossUpThreshold":
        thr = cfg["threshold"][0]
        dist = abs(value - thr) / (abs(thr) if thr != 0 else 1)
        return dist * 100

    # -------- IN RANGE THRESHOLD --------
    if t == "inRangeThreshold":
        lower = cfg["lower"][0]
        upper = cfg["upper"][0]

        if value < lower:
            return (abs(lower - value) / abs(lower)) * 100
        if value > upper:
            return (abs(value - upper) / abs(upper)) * 100
        return 0.0

    # -------- TIME THRESHOLD --------
    if t == "timeThreshold":
        direction = cfg["direction"][0]
        thr = cfg["threshold"][0]
        min_candles = cfg["min_candles"][0]

        series = ind_df[col]
        if direction == "below":
            cond = series < thr
        else:
            cond = series > thr

        streak = 0
        for x in reversed(cond.tolist()):
            if x:
                streak += 1
            else:
                break

        if streak >= min_candles:
            return 0.0

        missing = min_candles - streak
        return (missing / min_candles) * 100

    # -------- LINE CROSS (TWO INDICATORS) --------
    if t == "crossUpLineThreshold":
        ind1, ind2 = cfg["indicators"]
        p1, p2 = cfg["periods"]

        i1 = calculate_indicator(df.copy(), type=ind1, period=p1[0], plot=False)
        i2 = calculate_indicator(df.copy(), type=ind2, period=p2[0], plot=False)

        c1 = [c for c in i1.columns if c != "Date"][0]
        c2 = [c for c in i2.columns if c != "Date"][0]

        a = i1[c1].iloc[-1]
        b = i2[c2].iloc[-1]

        return abs(a - b) / (abs(b) if b != 0 else 1) * 100

    return None
