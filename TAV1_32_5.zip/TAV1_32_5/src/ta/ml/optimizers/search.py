from src.ta.functions.indicators.threshold_functions import *
from src.ta.functions.indicators.universal_threshold_dispatcher import *
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.pyplot as plt


import itertools
import pandas as pd

from src.ta.functions.indicators.threshold_functions import *
from src.ta.functions.indicators.universal_indicator_dispatcher import calculate_indicator


# ============================================================
# Helper: Expand any param dict into combinations
# ============================================================
def expand_params(param_dict):
    """
    Convert e.g. {"fast":[8,12], "slow":[21,26]}
    → [{"fast":8,"slow":21}, {"fast":8,"slow":26}, ...]
    """
    if not param_dict:
        return [{}]

    keys = list(param_dict.keys())
    vals = list(param_dict.values())

    combos = itertools.product(*vals)
    return [dict(zip(keys, combo)) for combo in combos]










# ============================================================
# GRID SEARCH ENGINE
# ============================================================
def gridSearch(df, search_space, mode="and"):
    results = []
    
    for space in search_space:

        ind_param_sets = expand_params(space.get("indicator_params", {}))
        t = space["type"]

        # ----------------------------------------------------
        # crossUpThreshold
        # ----------------------------------------------------
        if t == "crossUpThreshold":

            param_combinations = list(itertools.product(
                space["period"], 
                space["threshold"], 
                ind_param_sets
            ))

            # 🔥 INSERT HERE
            print("crossUpThreshold → Total combinations:", len(param_combinations))

            for per, thr, ind_kwargs in param_combinations:
                cfg = {
                    "type": "crossUpThreshold",
                    "indicator": space["indicator"],
                    "period": per,
                    "thr": thr,
                    "wd": space.get("wd", 0),
                    "indicator_params": ind_kwargs,
                }
                signals = run_threshold(df, cfg)
                results.append({"config": cfg, "signals": len(signals)})

        # ----------------------------------------------------
        # crossUpLineThreshold
        # ----------------------------------------------------
        elif t == "crossUpLineThreshold":

            param_combinations = list(itertools.product(
                space["periods"][0],
                space["periods"][1],
            ))

            # 🔥 INSERT HERE
            print("crossUpLineThreshold → Total combinations:", len(param_combinations))

            for p1, p2 in param_combinations:
                cfg = {
                    "type": "crossUpLineThreshold",
                    "ind1": space["indicators"][0],
                    "period1": p1,
                    "ind2": space["indicators"][1],
                    "period2": p2,
                    "wd": space.get("wd", 0),
                }
                signals = run_threshold(df, cfg)
                results.append({"config": cfg, "signals": len(signals)})

        # ----------------------------------------------------
        # inRangeThreshold
        # ----------------------------------------------------
        elif t == "inRangeThreshold":

            param_combinations = list(itertools.product(
                space["period"],
                space["lower"],
                space["upper"],
                ind_param_sets,
            ))

            # 🔥 INSERT HERE
            print("inRangeThreshold → Total combinations:", len(param_combinations))

            for per, low, upper, ind_kwargs in param_combinations:
                cfg = {
                    "type": "inRangeThreshold",
                    "indicator": space["indicator"],
                    "period": per,
                    "lower": low,
                    "upper": upper,
                    "wd": space.get("wd", 0),
                    "indicator_params": ind_kwargs,
                }
                signals = run_threshold(df, cfg)
                results.append({"config": cfg, "signals": len(signals)})

        # ----------------------------------------------------
        # timeThreshold
        # ----------------------------------------------------
        elif t == "timeThreshold":

            param_combinations = list(itertools.product(
                space["period"],
                space["threshold"],
                space["direction"],
                space["min_candles"],
                ind_param_sets,
            ))

            # 🔥 INSERT HERE
            print("timeThreshold → Total combinations:", len(param_combinations))

            for per, thr, direction, min_c, ind_kwargs in param_combinations:
                cfg = {
                    "type": "timeThreshold",
                    "indicator": space["indicator"],
                    "period": per,
                    "threshold": thr,
                    "direction": direction,
                    "min_candles": min_c,
                    "wd": space.get("wd", 0),
                    "indicator_params": ind_kwargs,
                }
                signals = run_threshold(df, cfg)
                results.append({"config": cfg, "signals": len(signals)})

        else:
            raise ValueError(f"Unsupported search space type: {t}")

    return results









# ============================================================
# UNIVERSAL THRESHOLD EXECUTOR
# ============================================================
def run_threshold(df, cfg):

    t = cfg["type"]

    # ----------------------------------------------
    # crossUpThreshold
    # ----------------------------------------------
    if t == "crossUpThreshold":
        return crossUpThreshold(
            df,
            type=cfg["indicator"],
            thr=cfg["thr"],
            period=cfg["period"],
            wd=cfg.get("wd", 0),
            **cfg.get("indicator_params", {})  #TODO like that if ylou want to explore indicator_params
        )

    # ----------------------------------------------
    # crossUpLineThreshold
    # ----------------------------------------------
    elif t == "crossUpLineThreshold":
        return crossUpLineThreshold(
            df,
            type1=cfg["ind1"],
            period1=cfg["period1"],
            type2=cfg["ind2"],
            period2=cfg["period2"],
            wd=cfg.get("wd", 0),
            **cfg.get("indicator_params1", {}),   # unpack parameters for indicator 1
            **cfg.get("indicator_params2", {}),   # unpack parameters for indicator 2
        )

    # ----------------------------------------------
    # inRangeThreshold
    # ----------------------------------------------
    elif t == "inRangeThreshold":
        return inRangeThreshold(
            df,
            type=cfg["indicator"],
            period=cfg["period"],
            lower=cfg["lower"],
            upper=cfg["upper"],
            **cfg.get("indicator_params", {})   # unpack correctly
        )






    # ----------------------------------------------
    # timeThreshold
    # ----------------------------------------------
    elif t == "timeThreshold":
        return timeThreshold(
            df,
            type=cfg["indicator"],
            period=cfg["period"],
            level=cfg["threshold"],
            direction=cfg["direction"],
            min_candles=cfg["min_candles"],
            wd=cfg.get("wd", 0),
            **cfg.get("indicator_params", {})
        )

    # ----------------------------------------------
    else:
        raise ValueError(f"Unsupported threshold type: {t}")







# ----------------------------------------------
# plotResultsPDF
# ----------------------------------------------
def plot_results_pdf(df, results, pdf_name="all_plots.pdf", top_n=None, signal_range=None):
    """
    UNIVERSAL plotting function.
    Accepts:
        - grid search results list (dicts)
        - a single DataFrame of signals
        - a list of signal DataFrames
        - a list of config dicts
    """

    # --- Normalize input into a list ---
    if isinstance(results, pd.DataFrame):
        results = [results]

    if isinstance(results, dict):  # single config dict
        results = [results]

    # --- Convert DataFrames to plot-ready result objects ---
    normalized_results = []

    for item in results:

        # Case 1: result is a grid-search dict
        if isinstance(item, dict) and "signals" in item and "config" in item:
            normalized_results.append(item)
            continue

        # Case 2: result is a config dict (User passed configs directly)
        if isinstance(item, dict) and "type" in item:
            sigs = run_threshold(df, item)
            normalized_results.append({
                "config": item,
                "signals": len(sigs),
                "signals_df": sigs
            })
            continue

        # Case 3: result is a DataFrame (mixThreshold)
        if isinstance(item, pd.DataFrame):
            normalized_results.append({
                "config": {"type": "mixThreshold"},
                "signals": len(item),
                "signals_df": item
            })
            continue

        raise ValueError(f"Unsupported item type: {type(item)}")

    # --- Sorting options ---
    normalized_results = sorted(normalized_results, key=lambda x: x["signals"], reverse=True)

    if top_n:
        normalized_results = normalized_results[:top_n]

    if signal_range:
        lo, hi = signal_range
        normalized_results = [r for r in normalized_results if lo <= r["signals"] <= hi]

    # --- Plotting ---
    with PdfPages(pdf_name) as pdf:
        for i, r in enumerate(normalized_results):

            cfg = r["config"]

            # Get signals dataframe
            if "signals_df" in r:
                signals = r["signals_df"]
            else:
                signals = run_threshold(df, cfg)

            plt.figure(figsize=(14, 6))
            plt.plot(df["Date"], df["close"], label="Price", color="black")

            # Draw signals
            if not signals.empty:
                pts = df[df["Date"].isin(signals["Date"])]
                plt.scatter(pts["Date"], pts["close"], color="green", s=40, label="Signals")

            plt.title(f"{cfg} | {len(signals)} signals")
            plt.xlabel("Date")
            plt.ylabel("Price")
            plt.legend()
            plt.grid(True)

            pdf.savefig()
            plt.close()

            print(f"📈 Added plot {i+1} → {pdf_name}")
